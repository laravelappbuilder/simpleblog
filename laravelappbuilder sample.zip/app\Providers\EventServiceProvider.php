<?php

namespace App\Providers;

use App\Events\BlogCreatedEvent;
use App\Events\BlogUpdatedEvent;
use App\Events\PostLikedEvent;
use App\Events\PostCommentedEvent;
use App\Events\PostRatedEvent;
use App\Listeners\BlogCreatedEventListener;
use App\Listeners\BlogUpdatedEventListener;
use App\Listeners\PostLikedEventListener;
use App\Listeners\PostCommentedEventListener;
use App\Listeners\PostRatedEventListener;
use Illuminate\Support\Facades\Event;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        BlogCreatedEvent::class => [
						BlogCreatedEventListener::class,
				],BlogUpdatedEvent::class => [
						BlogUpdatedEventListener::class,
				],PostLikedEvent::class => [
						PostLikedEventListener::class,
				],PostCommentedEvent::class => [
						PostCommentedEventListener::class,
				],PostRatedEvent::class => [
						PostRatedEventListener::class,
				],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
