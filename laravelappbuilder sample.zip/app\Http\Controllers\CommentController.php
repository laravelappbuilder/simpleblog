<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Auth;
use App\Comment;


class CommentController extends Controller
{
  public function __construct(){
    $this->middleware('auth',['except'=>array('index','show')]);
  }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $comments = Comment::where('commentable_id',$request->commentable_id)->where('commentable_type',$request->commentable_type)->paginate('10');
				return view('comments.index',compact('comments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('comments.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
          --storevalidation--
        ]);

        $comment = Comment::create($request->all());
				$comment->commentable_id = $request->commentable_id;
				$comment->commentable_type = $request->commentable_type;
				Session::flash('success','comment  successfully created');
				return redirect()->route('comments.show',['id'=>$comment->id,'commentable_id'=>$comment->commentable_id,'commentable_type'=>$comment->commentable_type]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $comments = Comment::find($request->id);
				return view('comments.show')->withComment($comments);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {

        $comments = Comment::find($request->id);
				return view('comments.edit')->withComment($comments);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $request->validate([
          --updatevalidation--
        ]);

        $comment->update($request->all());
				Session::flash('success','comment  successfully updated');
				return redirect()->route('comments.show',['id'=>$comment->id,'commentable_id'=>$comment->commentable_id,'commentable_type'=>$comment->commentable_type]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        
$comment->likes()->delete();
				$comment->delete();
				Session::flash('success','comment  successfully deleted');
				return redirect()->route('comments.index',['commentable_id'=>$comment->commentable_id,'commentable_type'=>$comment->commentable_type]);
    }
}
