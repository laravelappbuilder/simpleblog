<?php

namespace App\Listeners;

use App\Events\PostCommentedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Notifications\PostCommented;

class PostCommentedEventListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostCommentedEventListener  $event
     * @return void
     */
    public function handle(PostCommentedEvent $event)
    {
        $event->comment->user->notify(new PostCommented);
				
    }
}
