@extends('layouts.app')

@section('content')


<div class="container">
  {{ $comment->comment }}
<br>@can ('update',$comment)
	
		<a class="ui mini button" href="{{route('comment.edit',$comment->id)}}">edit</a>
		{!! Form::model($comment, ['route' => ['comment.update', $comment->id], 'method' => 'DELETE']) !!}
			{!! Form::submit("Delete", ['class' => 'ui negative']) !!}
		{!! Form::close() !!}
	
@endcan
</div>

@endsection
