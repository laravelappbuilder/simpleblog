<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\Relation;

Relation::morphMap([
		'blogs'=>'App\Blog',
		
]);


class Comment extends Model
{
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    protected $table = 'comments';

		protected $fillable = ['comment'];

		public function user(){
			return $this->belongsTo(User::class);
		}

		public function commentable(){
			return $this->morphTo();
		}

		public function likes(){
			return $this->morphMany('App\Like','likeable');
		}

		
    
}
