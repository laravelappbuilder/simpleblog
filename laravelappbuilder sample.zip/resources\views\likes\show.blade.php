@extends('layouts.app')

@section('content')


<div class="container">
  {{ $like->status }}
<br>@can ('update',$like)
	
		<a class="ui mini button" href="{{route('like.edit',$like->id)}}">edit</a>
		{!! Form::model($like, ['route' => ['like.update', $like->id], 'method' => 'DELETE']) !!}
			{!! Form::submit("Delete", ['class' => 'ui negative']) !!}
		{!! Form::close() !!}
	
@endcan
</div>

@endsection
