<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends Model
{
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    protected $table = 'blogs';

		protected $fillable = ['title','body','category_id'];

		public function user(){
			return $this->belongsTo(User::class);
		}

		public function category(){
			return $this->belongsTo(Category::class);
		}

		public function comments(){
			return $this->morphMany('App\Comment','commentable');
		}

		public function likes(){
			return $this->morphMany('App\Like','likeable');
		}

		public function ratings(){
			return $this->morphMany('App\Rating','ratingable');
		}

		public function tags(){
			return $this->morphToMany('App\Tag','tagable');
		}

		
    public function getRouteKeyName(){
			return 'slug';
		}
}
