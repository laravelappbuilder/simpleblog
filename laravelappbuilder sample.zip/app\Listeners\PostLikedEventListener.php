<?php

namespace App\Listeners;

use App\Events\PostLikedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Notifications\PostLikedNotification;

class PostLikedEventListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostLikedEventListener  $event
     * @return void
     */
    public function handle(PostLikedEvent $event)
    {
        $event->like->user->notify(new PostLikedNotification);
				
    }
}
