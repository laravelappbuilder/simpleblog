<?php

namespace App\Listeners;

use App\Events\BlogUpdatedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Mail;
use App\Mail\BlogUpdatedMailable;
use App\Notifications\BlogUpdatedNotification;

class BlogUpdatedEventListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  BlogUpdatedEventListener  $event
     * @return void
     */
    public function handle(BlogUpdatedEvent $event)
    {
        Mail::to($event->blog->user->email)->queue(new BlogUpdatedMailable());
				$event->blog->user->notify(new BlogUpdatedNotification);
				
    }
}
