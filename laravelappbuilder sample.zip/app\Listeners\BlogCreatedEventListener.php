<?php

namespace App\Listeners;

use App\Events\BlogCreatedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Mail;
use App\Mail\BlogCreatedMailable;
use App\Notifications\BlogCreatedNotification;

class BlogCreatedEventListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  BlogCreatedEventListener  $event
     * @return void
     */
    public function handle(BlogCreatedEvent $event)
    {
        Mail::to($event->blog->user->email)->queue(new BlogCreatedMailable());
				$event->blog->user->notify(new BlogCreatedNotification);
				
    }
}
