<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\StoreBlogRequest;
use App\Http\Requests\UpdateBlogRequest;
use Session;
use Auth;
use App\Blog;
use App\Category;
use App\Tag;


class BlogController extends Controller
{
  public function __construct(){
    $this->middleware('auth',['except'=>array('index','show')]);
    $this->authorizeResource(Blog::class);
  }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs = Blog::paginate('10');
				return view('blogs.index',compact('blogs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::pluck('name','id');
				$tags = Tag::pluck('name','id');
				return view('blogs.create',compact('categories','tags'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBlogRequest $request)
    {
        $blog = Blog::create($request->all());
				$blog->tags()->sync($request->tags,false);
				Session::flash('success','blog  successfully created');
				return redirect()->route('blogs.show',$blog->slug);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Blog $blog)
    {
        return view('blogs.show',compact('blog'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Blog $blog)
    {
        $categories = Category::pluck('name','id');
				$tags = Tag::pluck('name','id');
				return view('blogs.edit',compact('categories','tags','blog'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBlogRequest $request,Blog $blog)
    {
        $blog->update($request->all());
				$blog->tags()->sync($request->tags);
				Session::flash('success','blog  successfully updated');
				return redirect()->route('blogs.show',$blog->slug);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Blog $blog)
    {
        $blog->comments()->delete();
				$blog->likes()->delete();
				$blog->ratings()->delete();
				$blog->tags()->detach();
				$blog->delete();
				Session::flash('success','blog  successfully deleted');
				return redirect()->route('blogs.index');
    }
}
