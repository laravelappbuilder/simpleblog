<?php

use Faker\Generator as Faker;

$factory->define(App\Comment::class, function (Faker $faker) {
    return [
        'user_id' => function(){ return factory('App\User')->create()->id;},
				'commentable_id' => $faker->numberBetween(1,50),
				'commentable_type' => $faker->randomElement(['blogs']),
				'comment' => $faker->paragraphs(rand(5,10),true),
				
    ];
});
