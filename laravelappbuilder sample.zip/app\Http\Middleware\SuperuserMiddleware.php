<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class SuperuserMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::user()->email=='exampleemail@gmail.com') {
          return $next($request);
        }else {
          abort(403,"Not Authorised For This Action");

        }
    }
}
