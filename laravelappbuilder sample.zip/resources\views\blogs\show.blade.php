@extends('layouts.app')

@section('content')


<div class="container">
  <h3><a href="{{route('blogs.show',$blog->slug)}}">{{$blog->title}}</a></h3>
{{ $blog->body }}
<br>@can ('update',$blog)
	
		<a class="ui mini button" href="{{route('blogs.edit',$blog->slug)}}">edit</a>
		{!! Form::model($blog, ['route' => ['blogs.update', $blog->slug], 'method' => 'DELETE']) !!}
			{!! Form::submit("Delete", ['class' => 'ui negative']) !!}
		{!! Form::close() !!}
	
@endcan
</div>

@endsection
