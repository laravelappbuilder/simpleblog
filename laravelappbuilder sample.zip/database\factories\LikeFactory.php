<?php

use Faker\Generator as Faker;

$factory->define(App\Like::class, function (Faker $faker) {
    return [
        'user_id' => function(){ return factory('App\User')->create()->id;},
				'likeable_id' => $faker->numberBetween(1,50),
				'likeable_type' => $faker->randomElement(['blogs','comments']),
				'status' => $faker->numberBetween(1,50),
				
    ];
});
