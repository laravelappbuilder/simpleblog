<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
use App\Role;
use App\Category;
use App\Blog;
use App\Comment;
use App\Like;
use App\Rating;
use App\Tag;


class UpdateMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next,$model)
    {
        //Owner can edit and update their posts and articles

        if($model=='Role'){
					$row = Role::find($request->route()->parameter('role'));
				}elseif($model=='Category'){
					$row = Category::find($request->route()->parameter('category'));
				}elseif($model=='Blog'){
					$row = Blog::find($request->route()->parameter('blog'));
				}elseif($model=='Comment'){
					$row = Comment::find($request->route()->parameter('comment'));
				}elseif($model=='Like'){
					$row = Like::find($request->route()->parameter('like'));
				}elseif($model=='Rating'){
					$row = Rating::find($request->route()->parameter('rating'));
				}elseif($model=='Tag'){
					$row = Tag::find($request->route()->parameter('tag'));
				}else{
					return back();
				}

        if (empty($row)) {
          abort(404,'Row is empty inside middleware');
        }

        if ($row->user_id==Auth::user()->id) {
          return $next($request);
        }else {
          abort(403, 'You are not authorised for this action.');
        }
    }
}
