@extends('layouts.app')


@section('content')

        @if($blogs->isNotEmpty())
          @foreach ($blogs as $blog)
            <div class="container">
              <h3><a href="{{route('blogs.show',$blog->slug)}}">{{$blog->title}}</a></h3>
{{ $blog->body }}

            </div>

          @endforeach

            @if (empty($_GET))
						{{$blogs->links()}}
					@else
						{{$blogs->appends($_GET)->links()}}
					@endif

        @else
            <h3>No blog items found</h3>
        @endif


@endsection
