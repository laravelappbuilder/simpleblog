<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
use App\Role;
use App\Category;
use App\Blog;
use App\Comment;
use App\Like;
use App\Rating;
use App\Tag;


class DeleteMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next,$model)
    {
        //Owner or Admin can delete posts articles or categories or violent comments

        if($model=='Role'){
					$row = Role::find($request->route()->parameter('role'));
				}elseif($model=='Category'){
					$row = Category::find($request->route()->parameter('category'));
				}elseif($model=='Blog'){
					$row = Blog::find($request->route()->parameter('blog'));
				}elseif($model=='Comment'){
					$row = Comment::find($request->route()->parameter('comment'));
				}elseif($model=='Like'){
					$row = Like::find($request->route()->parameter('like'));
				}elseif($model=='Rating'){
					$row = Rating::find($request->route()->parameter('rating'));
				}elseif($model=='Tag'){
					$row = Tag::find($request->route()->parameter('tag'));
				}else{
					return back();
				}


        if (empty($row)) {
          abort(404,'Page Not Found');
        }

        if ($row->user_id==Auth::user()->id || Auth::user()->roles()->where('role','Admin')->first()!=null) {
          return $next($request);
        }else {
          abort(403, 'You are not authorised for this action.');
        }
    }
}
