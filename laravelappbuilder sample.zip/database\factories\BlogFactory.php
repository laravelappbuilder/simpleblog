<?php

use Faker\Generator as Faker;

$factory->define(App\Blog::class, function (Faker $faker) {
    return [
        'user_id' => function(){ return factory('App\User')->create()->id;},
				'category_id' => function(){ return factory('App\Category')->create()->id;},
				'title' => $faker->sentence(),
				'slug' => str_slug($faker->unique()->sentence()),
				'body' => $faker->paragraphs(rand(5,10),true),
				
    ];
});
