<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Auth;
use App\Like;


class LikeController extends Controller
{
  public function __construct(){
    $this->middleware('auth',['except'=>array('index','show')]);
  }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $likes = Like::where('likeable_id',$request->likeable_id)->where('likeable_type',$request->likeable_type)->paginate('10');
				return view('likes.index',compact('likes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view('likes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
          --storevalidation--
        ]);

        $like = Like::create($request->all());
				$like->likeable_id = $request->likeable_id;
				$like->likeable_type = $request->likeable_type;
				Session::flash('success','like  successfully created');
				return redirect()->route('likes.show',['id'=>$like->id,'likeable_id'=>$like->likeable_id,'likeable_type'=>$like->likeable_type]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $likes = Like::find($request->id);
				return view('likes.show')->withLike($likes);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {

        $likes = Like::find($request->id);
				return view('likes.edit')->withLike($likes);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $request->validate([
          --updatevalidation--
        ]);

        $like->update($request->all());
				Session::flash('success','like  successfully updated');
				return redirect()->route('likes.show',['id'=>$like->id,'likeable_id'=>$like->likeable_id,'likeable_type'=>$like->likeable_type]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        
$like->delete();
				Session::flash('success','like  successfully deleted');
				return redirect()->route('likes.index',['likeable_id'=>$like->likeable_id,'likeable_type'=>$like->likeable_type]);
    }
}
