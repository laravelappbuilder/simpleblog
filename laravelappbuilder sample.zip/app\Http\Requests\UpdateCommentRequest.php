<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCommentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
          'comment' => 'string|required|min:3|min:5000'
        ];
    }

    public function messages()
    {
        return [
            'comment.string'=>'Comment must be string',
						'comment.required'=>'Comment field is required',
						'comment.min'=>'Comment must be minimum 3 characters long',
						'comment.min'=>'Comment cannot be more than 5000 characters'
        ];
    }
}
