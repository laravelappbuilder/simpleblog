<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('roles','RoleController');
Route::resource('categories','CategoryController');
Route::resource('blogs','BlogController');
Route::post('comment/{commentable_type}/{commentable_id}',['as'=>'comment.store','uses'=>'CommentController@store'])->where('commentable_id','[0-9]+')->where('commentable_type','[a-z]+');
Route::resource('comment','CommentController');
Route::post('like/{likeable_type}/{likeable_id}',['as'=>'like.store','uses'=>'LikeController@store'])->where('likeable_id','[0-9]+')->where('likeable_type','[a-z]+');
Route::resource('like','LikeController');
Route::post('ratings/{ratingable_type}/{ratingable_id}',['as'=>'ratings.store','uses'=>'RatingController@store'])->where('ratingable_id','[0-9]+')->where('ratingable_type','[a-z]+');
Route::resource('ratings','RatingController');
Route::resource('tag','TagController');

