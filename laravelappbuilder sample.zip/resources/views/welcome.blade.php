@extends('layouts.app')

@section('content')

<h1>Congratulations</h1>
<p>Your Final Laravel App Is Here</p>

@endsection

