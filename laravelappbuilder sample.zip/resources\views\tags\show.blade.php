@extends('layouts.app')

@section('content')


<div class="container">
  <h3><a href="{{route('tag.show',$tag->id)}}">{{$tag->name}}</a></h3>
<br>@can ('update',$tag)
	
		<a class="ui mini button" href="{{route('tag.edit',$tag->id)}}">edit</a>
		{!! Form::model($tag, ['route' => ['tag.update', $tag->id], 'method' => 'DELETE']) !!}
			{!! Form::submit("Delete", ['class' => 'ui negative']) !!}
		{!! Form::close() !!}
	
@endcan
</div>

@endsection
