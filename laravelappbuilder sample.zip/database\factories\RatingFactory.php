<?php

use Faker\Generator as Faker;

$factory->define(App\Rating::class, function (Faker $faker) {
    return [
        'user_id' => function(){ return factory('App\User')->create()->id;},
				'ratingable_id' => $faker->numberBetween(1,50),
				'ratingable_type' => $faker->randomElement(['blogs']),
				'rating' => $faker->numberBetween(1,50),
				
    ];
});
