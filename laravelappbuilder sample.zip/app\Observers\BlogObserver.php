<?php

namespace App\Observers;

use App\Blog;
use Auth;
use Event;

class BlogObserver
{
    /**
     * Handle the Blog "creating" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function creating(Blog $blog)
    {
        $blog->user_id = Auth::user()->id;
				if (Blog::where('slug',str_slug($blog->title))->first()==null) {
					$slug = str_slug($blog->title);
				}else {
					$slug = str_slug($blog->title).'-'.uniqid();
				}
				$blog->slug = $slug;
    }

    /**
     * Handle the Blog "created" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function created(Blog $blog)
    {
        Event::fire(new \App\Events\BlogCreatedEvent($blog));Event::fire(new \App\Events\BlogCreatedEvent($blog));
    }

    /**
     * Handle the Blog "updating" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function updating(Blog $blog)
    {
        if ($blog->getOriginal('title')!=$blog->title) {
					if (Blog::where('slug',str_slug($blog->title))->first()==null) {
						$blog->slug = str_slug($blog->title);
					}else {
						$blog->slug = str_slug($blog->title).'-'.uniqid();
					}
				}
    }

    /**
     * Handle the Blog "updated" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function updated(Blog $blog)
    {
        Event::fire(new \App\Events\BlogUpdatedEvent($blog));Event::fire(new \App\Events\BlogUpdatedEvent($blog));
    }

    /**
     * Handle the Blog "deleting" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function deleting(Blog $blog)
    {
        //
    }

    /**
     * Handle the Blog "deleted" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function deleted(Blog $blog)
    {
        //
    }

    /**
     * Handle the Blog "Restoring" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function restoring(Blog $blog)
    {
        //
    }

    /**
     * Handle the Blog "restored" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function restored(Blog $blog)
    {
        //
    }

    /**
     * Handle the Blog "force deleted" event.
     *
     * @param  \App\Blog  $blog
     * @return void
     */
    public function forceDeleted(Blog $blog)
    {
        //
    }
}
