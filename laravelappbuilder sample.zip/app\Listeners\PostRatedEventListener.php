<?php

namespace App\Listeners;

use App\Events\PostRatedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Notifications\PostRated;

class PostRatedEventListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostRatedEventListener  $event
     * @return void
     */
    public function handle(PostRatedEvent $event)
    {
        $event->rating->user->notify(new PostRated);
				
    }
}
